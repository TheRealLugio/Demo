# Kava Coast
This project is currently undergoing significant development and restructuring. As a result, the main branch may be unstable and is subject to frequent changes.

The last stable release (Version 1) is available here: [v1](https://github.com/Elgenzay/kavacoast/tree/v1)
